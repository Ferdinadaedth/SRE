# Level1 

```  c
#include<stdio.h>
int i;
void bitSwap(unsigned int x)
{
	char* p = (char*)&i;//将int型指针转换成char型指针
	char t = p[0];
	p[0] = p[3];
	p[3] = t;
	t = p[1];
	p[1] = p[2];
	p[2] = t;//通过中间变量将int类型高低字节位交换
}
int main()
{
	scanf("%X", &i);
	bitSwap(i);
	printf("0X%X\n", i);
	return 0;

}

```

 

